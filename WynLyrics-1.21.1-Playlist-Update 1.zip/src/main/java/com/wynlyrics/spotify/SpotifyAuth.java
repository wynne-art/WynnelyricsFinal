package com.wynlyrics.spotify;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.wynlyrics.WynLyricsClient;
import com.wynlyrics.config.WynConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Util;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Spotify Authorization Code + PKCE login. No client secret is used or stored.
 * A tiny loopback server (plain ServerSocket) receives the redirect.
 */
public final class SpotifyAuth {
    public enum State { LOGGED_OUT, WAITING, EXCHANGING, LOGGED_IN, ERROR }

    private static final String AUTH_URL = "https://accounts.spotify.com/authorize";
    private static final String TOKEN_URL = "https://accounts.spotify.com/api/token";
    private static final String SCOPES = "user-read-currently-playing user-read-playback-state user-modify-playback-state playlist-read-private playlist-read-collaborative";

    private static final Object LOCK = new Object();
    private static volatile State state = State.LOGGED_OUT;
    private static volatile String message = "";
    private static volatile String authUrl = "";
    private static volatile String accessToken = "";
    private static volatile String refreshToken = "";
    private static volatile long expiresAtMs = 0;
    private static volatile String tokenClientId = "";
    private static volatile ServerSocket server;

    private SpotifyAuth() {}

    // ------------------------------------------------------------ getters

    public static State state() { return state; }
    public static String message() { return message; }
    public static String authUrl() { return authUrl; }
    public static boolean isLoggedIn() { return state == State.LOGGED_IN && !refreshToken.isEmpty(); }
    public static String getAccessToken() { String t = validToken(); return t != null ? t : ""; }
    public static String redirectUri() { return "http://127.0.0.1:" + WynConfig.CONFIG.spotifyRedirectPort + "/callback"; }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("wynlyrics").resolve("spotify_auth.json");
    }

    // ------------------------------------------------------------ persistence

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try {
            JsonObject o = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            accessToken = str(o, "access_token");
            refreshToken = str(o, "refresh_token");
            tokenClientId = str(o, "client_id");
            expiresAtMs = o.has("expires_at") ? o.get("expires_at").getAsLong() : 0;
            if (!refreshToken.isEmpty()) state = State.LOGGED_IN;
        } catch (Exception e) {
            WynLyricsClient.LOGGER.warn("Could not read Spotify auth file: {}", e.getMessage());
        }
    }

    private static void save() {
        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            JsonObject o = new JsonObject();
            o.addProperty("access_token", accessToken);
            o.addProperty("refresh_token", refreshToken);
            o.addProperty("expires_at", expiresAtMs);
            o.addProperty("client_id", tokenClientId);
            Files.writeString(f, o.toString());
            try { Files.setPosixFilePermissions(f, PosixFilePermissions.fromString("rw-------")); }
            catch (Exception ignored) { /* non-POSIX file system */ }
        } catch (IOException e) {
            WynLyricsClient.LOGGER.warn("Could not save Spotify auth file: {}", e.getMessage());
        }
    }

    private static String str(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
    }

    // ------------------------------------------------------------ login flow

    public static void startLogin() {
        synchronized (LOCK) {
            String cid = WynConfig.CONFIG.spotifyClientId.trim();
            if (cid.isEmpty()) { fail("Client ID is empty"); return; }
            closeServer();

            String verifier = Pkce.verifier();
            String expectedState = Pkce.state();
            String redirect = redirectUri();

            ServerSocket ss;
            try {
                ss = new ServerSocket(WynConfig.CONFIG.spotifyRedirectPort, 4, InetAddress.getByName("127.0.0.1"));
                ss.setSoTimeout(1000);
            } catch (IOException e) {
                fail("Port " + WynConfig.CONFIG.spotifyRedirectPort + " is unavailable");
                return;
            }
            server = ss;

            Map<String, String> q = new LinkedHashMap<>();
            q.put("response_type", "code");
            q.put("client_id", cid);
            q.put("scope", SCOPES);
            q.put("redirect_uri", redirect);
            q.put("state", expectedState);
            q.put("code_challenge_method", "S256");
            q.put("code_challenge", Pkce.challenge(verifier));
            StringBuilder url = new StringBuilder(AUTH_URL).append('?');
            q.forEach((k, v) -> url.append(URLEncoder.encode(k, StandardCharsets.UTF_8)).append('=')
                    .append(URLEncoder.encode(v, StandardCharsets.UTF_8)).append('&'));
            authUrl = url.substring(0, url.length() - 1);

            state = State.WAITING;
            message = "";

            try {
                Util.getOperatingSystem().open(URI.create(authUrl));
            } catch (Throwable t) {
                message = "Browser could not be opened. Use \"Copy link\".";
            }

            Thread th = new Thread(() -> listen(ss, verifier, expectedState, cid, redirect), "WynLyrics-SpotifyAuth");
            th.setDaemon(true);
            th.start();
        }
    }

    public static void cancel() {
        synchronized (LOCK) {
            closeServer();
            if (state == State.WAITING || state == State.EXCHANGING) {
                state = refreshToken.isEmpty() ? State.LOGGED_OUT : State.LOGGED_IN;
                message = "";
            }
        }
    }

    public static void shutdown() { synchronized (LOCK) { closeServer(); } }

    public static void logout() {
        synchronized (LOCK) {
            closeServer();
            accessToken = ""; refreshToken = ""; expiresAtMs = 0; tokenClientId = "";
            try { Files.deleteIfExists(file()); } catch (IOException ignored) {}
            state = State.LOGGED_OUT;
            message = "";
        }
    }

    private static void closeServer() {
        ServerSocket s = server;
        server = null;
        if (s != null) try { s.close(); } catch (IOException ignored) {}
    }

    private static void fail(String msg) {
        state = State.ERROR;
        message = msg;
        WynLyricsClient.LOGGER.warn("Spotify auth: {}", msg);
    }

    private static void listen(ServerSocket ss, String verifier, String expectedState, String cid, String redirect) {
        long deadline = System.currentTimeMillis() + 180_000L;
        try {
            while (server == ss && System.currentTimeMillis() < deadline) {
                Socket s;
                try { s = ss.accept(); } catch (SocketTimeoutException e) { continue; }
                try (s) {
                    s.setSoTimeout(5000);
                    BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                    String line = r.readLine();
                    if (line == null) continue;
                    String[] parts = line.split(" ");
                    if (parts.length < 2 || !parts[1].startsWith("/callback")) { respond(s, 404, "Not found"); continue; }
                    Map<String, String> params = parseQuery(parts[1]);
                    if (params.containsKey("error")) {
                        respond(s, 400, page(false));
                        fail("Spotify: " + params.get("error"));
                        return;
                    }
                    String code = params.get("code");
                    if (code == null || !expectedState.equals(params.get("state"))) {
                        respond(s, 400, page(false));
                        fail("Invalid login response");
                        return;
                    }
                    respond(s, 200, page(true));
                    state = State.EXCHANGING;
                    exchange(code, verifier, cid, redirect);
                    return;
                } catch (IOException ignored) {
                    // speculative/blank browser connection: keep waiting
                }
            }
            if (server == ss) fail("Login timed out");
        } finally {
            synchronized (LOCK) { if (server == ss) closeServer(); }
        }
    }

    private static void exchange(String code, String verifier, String cid, String redirect) {
        try {
            Map<String, String> f = new LinkedHashMap<>();
            f.put("grant_type", "authorization_code");
            f.put("code", code);
            f.put("redirect_uri", redirect);
            f.put("client_id", cid);
            f.put("code_verifier", verifier);
            Http.Response r = Http.postForm(TOKEN_URL, f, 10_000);
            if (r.code() != 200) { fail("Token exchange failed (HTTP " + r.code() + ")"); return; }
            applyTokens(r.body(), cid);
            WynConfig.CONFIG.spotifyEnabled = true;
            WynConfig.save();
        } catch (Exception e) {
            fail("Token exchange failed: " + e.getMessage());
        }
    }

    private static void applyTokens(String body, String cid) {
        JsonObject o = JsonParser.parseString(body).getAsJsonObject();
        synchronized (LOCK) {
            accessToken = str(o, "access_token");
            String rt = str(o, "refresh_token");
            if (!rt.isEmpty()) refreshToken = rt;
            long ttl = o.has("expires_in") ? o.get("expires_in").getAsLong() : 3600;
            expiresAtMs = System.currentTimeMillis() + ttl * 1000L;
            tokenClientId = cid;
            state = State.LOGGED_IN;
            message = "";
            save();
        }
    }

    // ------------------------------------------------------------ token access (worker thread)

    /** Returns a valid access token (refreshing when needed), or null when not logged in. Blocking. */
    public static String validToken() {
        synchronized (LOCK) {
            String cid = WynConfig.CONFIG.spotifyClientId.trim();
            if (refreshToken.isEmpty() || cid.isEmpty() || !cid.equals(tokenClientId)) return null;
            if (accessToken.isEmpty() || System.currentTimeMillis() > expiresAtMs - 60_000L) {
                if (!refresh(cid)) return null;
            }
            return accessToken;
        }
    }

    public static void invalidateAccess() { expiresAtMs = 0; }

    private static boolean refresh(String cid) {
        try {
            Map<String, String> f = new LinkedHashMap<>();
            f.put("grant_type", "refresh_token");
            f.put("refresh_token", refreshToken);
            f.put("client_id", cid);
            Http.Response r = Http.postForm(TOKEN_URL, f, 10_000);
            if (r.code() == 200) { applyTokens(r.body(), cid); return true; }
            if (r.code() == 400 || r.code() == 401) {
                accessToken = ""; refreshToken = ""; expiresAtMs = 0;
                try { Files.deleteIfExists(file()); } catch (IOException ignored) {}
                fail("Session expired, please log in again");
            }
        } catch (Exception e) {
            WynLyricsClient.LOGGER.warn("Spotify token refresh failed: {}", e.getMessage());
        }
        return false;
    }

    // ------------------------------------------------------------ helpers

    public static Map<String, String> parseQuery(String target) {
        Map<String, String> out = new LinkedHashMap<>();
        int i = target.indexOf('?');
        if (i < 0) return out;
        for (String pair : target.substring(i + 1).split("&")) {
            if (pair.isEmpty()) continue;
            int eq = pair.indexOf('=');
            String k = eq < 0 ? pair : pair.substring(0, eq);
            String v = eq < 0 ? "" : pair.substring(eq + 1);
            out.put(URLDecoder.decode(k, StandardCharsets.UTF_8), URLDecoder.decode(v, StandardCharsets.UTF_8));
        }
        return out;
    }

    private static String page(boolean ok) {
        String msg = ok ? "WynLyrics is connected to Spotify. You can close this tab and return to Minecraft."
                        : "Login failed. Return to Minecraft and try again.";
        return "<!doctype html><html><head><meta charset=\"utf-8\"><title>WynLyrics</title></head>"
                + "<body style=\"font-family:sans-serif;background:#10131b;color:#fff;text-align:center;padding-top:15vh\">"
                + "<h2>WynLyrics</h2><p>" + msg + "</p></body></html>";
    }

    private static void respond(Socket s, int code, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        String head = "HTTP/1.1 " + code + (code == 200 ? " OK" : code == 404 ? " Not Found" : " Bad Request") + "\r\n"
                + "Content-Type: text/html; charset=utf-8\r\nContent-Length: " + b.length + "\r\nConnection: close\r\n\r\n";
        OutputStream out = s.getOutputStream();
        out.write(head.getBytes(StandardCharsets.US_ASCII));
        out.write(b);
        out.flush();
    }

    /** Copies the login link to the clipboard (client thread safe). */
    public static void copyLink() {
        String url = authUrl;
        if (url.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.execute(() -> mc.keyboard.setClipboard(url));
    }
}
