# WynLyrics 1.0.0

Client-side Fabric mod for Minecraft **1.21.1**: synced lyrics HUD, Spotify login, 3D floating lyrics,
HUD editor, cosmetic editor, custom fonts and animations. Original implementation inspired by the
feature category of the reference mod; no code or assets reused.

## Features
- Lyrics HUD with LRC parsing (multi-timestamp, `[offset:]`, word-tag stripping) and karaoke-style line fill.
- **Spotify OAuth login** (Authorization Code + PKCE, no client secret, no manual token).
- **3D floating lyrics**: billboarded in the world, *follow* or *anchored* mode, optional see-through.
- **Custom fonts**: Poppins (bundled), Bebas Neue, Lobster, Pacifico, Righteous, Satisfy, Unicode.
- **HUD editor**: drag, scroll-to-scale, width, opacity, alignment, snap to center.
- **Cosmetic editor**: 7 themes, per-element color (RGB + hex), shadow/outline/glow, rounded corners, border, fonts.
- **Animations**: none, fade, slide, zoom, typewriter + HUD fade in/out.
- Full in-game settings (tabs: General, Spotify, Lyrics, Animation, 3D).

## Controls
| Key | Action |
| --- | --- |
| `L` | Toggle lyrics HUD |
| `K` | Toggle 3D floating lyrics |
| `O` | Open settings (all keys are rebindable) |

HUD editor: drag the box, scroll to scale, arrow keys nudge, `H` hides the panel.

## Build
1. Install JDK 21.
2. Run `gradle wrapper` once (the wrapper files are not included), then `./gradlew build`
   (Windows: `gradlew.bat build`) — or open the folder in IntelliJ IDEA.
3. The JAR is in `build/libs/`. Put it in `.minecraft/mods` together with Fabric API 0.102.1+1.21.1.

Fonts: Poppins is bundled. The `fetchFonts` Gradle task downloads the other OFL fonts on first build.
If a download fails you only get a warning; drop the TTF into `src/main/resources/assets/wynlyrics/font/`
using the names `bebas.ttf`, `lobster.ttf`, `pacifico.ttf`, `righteous.ttf`, `satisfy.ttf`.
Fonts that are missing are hidden in the editor.

## Spotify login (one-time setup)
1. Go to the Spotify Developer Dashboard and create an app.
2. Add this Redirect URI: `http://127.0.0.1:8888/callback` (the port is `spotifyRedirectPort` in the config).
3. Copy the app's **Client ID** into *Settings → Spotify*, then press **Log in with Spotify**.
4. Approve in the browser. Tokens are stored in `config/wynlyrics/spotify_auth.json` and refreshed automatically.

No client secret is needed or stored. Do not share `spotify_auth.json`.

## Lyrics files
Put `.lrc` files in `config/wynlyrics/`. With Spotify, lookup order is `Artist - Title.lrc`, then `Title.lrc`.
Without Spotify, `lyricsFile` (default `current_song.lrc`) is played from the moment the game starts / reload.
Spotify does not provide synced lyrics, so you supply the `.lrc` files. Use *Lyrics → Timing* to correct sync.

## Self tests
`tools/selftest/run.sh` compiles and runs checks for the Minecraft-independent logic (LRC parser,
PKCE against the RFC 7636 vector, animation layout, color helpers) using only a JDK.

## Config
`config/wynlyrics.json` is generated on first run; everything in it is editable from the GUI.
Old configs are migrated (`fontScale` → `hudScale`).
