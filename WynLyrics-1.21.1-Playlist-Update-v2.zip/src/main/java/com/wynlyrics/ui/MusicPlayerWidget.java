package com.wynlyrics.ui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.wynlyrics.config.WynConfig;
import com.wynlyrics.music.MusicPlaybackController;
import com.wynlyrics.music.MusicPlaybackController.RepeatMode;
import com.wynlyrics.render.Draw;
import com.wynlyrics.util.ColorUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

/**
 * Interactive LyricsFlow-style music player control bar with transport buttons
 * (repeat/repeat_one, prev, play/pause, next, mute, volume slider), clickable seek bar,
 * and source switcher (Spotify, YT Music, YouTube, Saved Local).
 */
public final class MusicPlayerWidget {

    private static final Identifier ICON_PLAY = Identifier.of("wynlyrics", "textures/gui/icons/play.png");
    private static final Identifier ICON_PAUSE = Identifier.of("wynlyrics", "textures/gui/icons/pause.png");
    private static final Identifier ICON_NEXT = Identifier.of("wynlyrics", "textures/gui/icons/next.png");
    private static final Identifier ICON_PREV = Identifier.of("wynlyrics", "textures/gui/icons/prev.png");
    private static final Identifier ICON_REPEAT = Identifier.of("wynlyrics", "textures/gui/icons/repeat.png");
    private static final Identifier ICON_REPEAT_ONE = Identifier.of("wynlyrics", "textures/gui/icons/repeat_one.png");
    private static final Identifier ICON_VOLUME = Identifier.of("wynlyrics", "textures/gui/icons/volume.png");
    private static final Identifier ICON_MUTE = Identifier.of("wynlyrics", "textures/gui/icons/mute.png");

    private static final Identifier LOGO_SPOTIFY = Identifier.of("wynlyrics", "textures/gui/logos/spotify.png");
    private static final Identifier LOGO_YOUTUBE = Identifier.of("wynlyrics", "textures/gui/logos/youtube.png");
    private static final Identifier LOGO_YTMUSIC = Identifier.of("wynlyrics", "textures/gui/logos/ytmusic.png");

    private final int x;
    private final int y;
    private final int width;
    private final int height;

    public MusicPlayerWidget(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void render(DrawContext ctx, int mouseX, int mouseY) {
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        MusicPlaybackController ctrl = MusicPlaybackController.getInstance();
        WynConfig.Config c = WynConfig.CONFIG;

        int accent = 0xFF000000 | c.accentColor;
        Draw.fillRounded(ctx, x, y, x + width, y + height, 4, ColorUtil.argb(c.backgroundColor, 0.85f));
        ctx.drawBorder(x, y, width, height, ColorUtil.argb(c.accentColor, 0.55f));

        Identifier logo = switch (ctrl.getActiveSource()) {
            case SPOTIFY -> LOGO_SPOTIFY;
            case YOUTUBE -> LOGO_YOUTUBE;
            case YT_MUSIC -> LOGO_YTMUSIC;
            case LOCAL -> ICON_PLAY;
        };
        drawIcon(ctx, tr, logo, "\u266A", x + 6, y + 6, 12, accent);

        String srcLabel = ctrl.getActiveSource().displayName;
        int pillW = tr.getWidth(srcLabel) + 8;
        int pillX = x + width - pillW - 6;
        int pillY = y + 4;
        boolean hoverPill = mouseX >= pillX && mouseX <= pillX + pillW && mouseY >= pillY && mouseY <= pillY + 12;
        Draw.fillRounded(ctx, pillX, pillY, pillX + pillW, pillY + 12, 3, hoverPill ? 0x55FFFFFF : 0x33FFFFFF);
        ctx.drawTextWithShadow(tr, srcLabel, pillX + 4, pillY + 2, 0xFFFFFFFF);

        int maxTextW = width - pillW - 34;
        String title = tr.trimToWidth(ctrl.getCurrentTitle(), Math.max(40, maxTextW));
        String artist = tr.trimToWidth(ctrl.getCurrentArtist(), Math.max(40, maxTextW));
        ctx.drawTextWithShadow(tr, title, x + 22, y + 4, 0xFFFFFFFF);
        ctx.drawTextWithShadow(tr, artist, x + 22, y + 14, 0xFFA5B0C2);

        long pos = ctrl.getProgressMs();
        long dur = ctrl.getDurationMs();
        String tLeft = Draw.time(pos);
        String tRight = Draw.time(dur);
        int timeW = tr.getWidth(tRight) + 4;

        int barX = x + 6 + timeW;
        int barW = width - 12 - timeW * 2;
        int barY = y + 25;
        float ratio = Math.max(0f, Math.min(1f, (float) pos / dur));

        ctx.drawText(tr, tLeft, x + 6, barY - 2, 0xFF9AA0AA, false);
        ctx.drawText(tr, tRight, x + width - 6 - tr.getWidth(tRight), barY - 2, 0xFF9AA0AA, false);
        ctx.fill(barX, barY, barX + barW, barY + 3, 0xFF343B4A);
        ctx.fill(barX, barY, barX + (int) (barW * ratio), barY + 3, accent);

        int btnY = y + 31;
        int centerX = x + width / 2;

        Identifier repIcon = (ctrl.getRepeatMode() == RepeatMode.ONE) ? ICON_REPEAT_ONE : ICON_REPEAT;
        int repTint = (ctrl.getRepeatMode() == RepeatMode.OFF) ? 0xFF8892A4 : accent;
        drawTintedIcon(ctx, tr, repIcon, "\u21BB", centerX - 46, btnY, 10, repTint);
        drawIcon(ctx, tr, ICON_PREV, "\u23EE", centerX - 25, btnY, 10, 0xFFFFFFFF);
        drawIcon(ctx, tr, ctrl.isPlaying() ? ICON_PAUSE : ICON_PLAY,
                ctrl.isPlaying() ? "\u23F8" : "\u25B6", centerX - 5, btnY - 1, 11, 0xFFFFFFFF);
        drawIcon(ctx, tr, ICON_NEXT, "\u23ED", centerX + 16, btnY, 10, 0xFFFFFFFF);

        int muteX = x + width - 54;
        Identifier volIcon = ctrl.isMuted() ? ICON_MUTE : ICON_VOLUME;
        drawIcon(ctx, tr, volIcon, ctrl.isMuted() ? "M" : "V", muteX, btnY, 10, 0xFFFFFFFF);

        int volX = x + width - 40;
        int volW = 34;
        ctx.fill(volX, btnY + 4, volX + volW, btnY + 6, 0xFF343B4A);
        ctx.fill(volX, btnY + 4, volX + (int) (volW * (ctrl.getVolumePercent() / 100f)), btnY + 6, 0xFFFFFFFF);
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0 || mouseX < x || mouseX > x + width || mouseY < y || mouseY > y + height) {
            return false;
        }

        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        MusicPlaybackController ctrl = MusicPlaybackController.getInstance();

        String srcLabel = ctrl.getActiveSource().displayName;
        int pillW = tr.getWidth(srcLabel) + 8;
        int pillX = x + width - pillW - 6;
        int pillY = y + 4;
        if (mouseX >= pillX && mouseX <= pillX + pillW && mouseY >= pillY && mouseY <= pillY + 13) {
            ctrl.cycleSource();
            playClick();
            return true;
        }

        int timeW = tr.getWidth(Draw.time(ctrl.getDurationMs())) + 4;
        int barX = x + 6 + timeW;
        int barW = width - 12 - timeW * 2;
        int barY = y + 23;
        if (mouseY >= barY && mouseY <= barY + 7 && mouseX >= barX && mouseX <= barX + barW) {
            double ratio = (mouseX - barX) / (double) barW;
            ctrl.seekTo((long) (ctrl.getDurationMs() * ratio));
            playClick();
            return true;
        }

        int btnY = y + 29;
        int centerX = x + width / 2;
        if (mouseY >= btnY && mouseY <= btnY + 14) {
            if (mouseX >= centerX - 49 && mouseX <= centerX - 33) {
                ctrl.cycleRepeatMode();
            } else if (mouseX >= centerX - 28 && mouseX <= centerX - 12) {
                ctrl.previousTrack();
            } else if (mouseX >= centerX - 8 && mouseX <= centerX + 9) {
                ctrl.togglePlayPause();
            } else if (mouseX >= centerX + 13 && mouseX <= centerX + 29) {
                ctrl.nextTrack();
            } else if (mouseX >= x + width - 56 && mouseX <= x + width - 42) {
                ctrl.toggleMute();
            } else if (mouseX >= x + width - 41 && mouseX <= x + width - 5) {
                double volRatio = (mouseX - (x + width - 40)) / 34.0;
                ctrl.setVolume((int) Math.round(volRatio * 100));
            } else {
                return false;
            }
            playClick();
            return true;
        }

        return false;
    }

    private void drawIcon(DrawContext ctx, TextRenderer tr, Identifier tex, String fallback,
                          int dx, int dy, int size, int fallbackColor) {
        boolean exists = MinecraftClient.getInstance().getResourceManager().getResource(tex).isPresent();
        if (exists) {
            RenderSystem.enableBlend();
            ctx.drawTexture(tex, dx, dy, 0f, 0f, size, size, size, size);
        } else {
            ctx.drawTextWithShadow(tr, fallback, dx + 1, dy + 1, fallbackColor);
        }
    }

    private void drawTintedIcon(DrawContext ctx, TextRenderer tr, Identifier tex, String fallback,
                                int dx, int dy, int size, int argb) {
        boolean exists = MinecraftClient.getInstance().getResourceManager().getResource(tex).isPresent();
        if (exists) {
            float a = ((argb >>> 24) & 0xFF) / 255f;
            float r = ((argb >>> 16) & 0xFF) / 255f;
            float g = ((argb >>> 8) & 0xFF) / 255f;
            float b = (argb & 0xFF) / 255f;
            RenderSystem.enableBlend();
            RenderSystem.setShaderColor(r, g, b, a);
            ctx.drawTexture(tex, dx, dy, 0f, 0f, size, size, size, size);
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        } else {
            ctx.drawTextWithShadow(tr, fallback, dx + 1, dy + 1, argb);
        }
    }

    private void playClick() {
        MinecraftClient.getInstance().getSoundManager()
                .play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }
}
