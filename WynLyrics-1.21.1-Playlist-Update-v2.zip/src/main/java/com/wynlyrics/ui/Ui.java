package com.wynlyrics.ui;

import com.wynlyrics.config.WynConfig;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;

import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/** Small widget factory helpers shared by the screens. */
final class Ui {
    private Ui() {}

    static Text t(String key, Object... args) { return Text.translatable(key, args); }

    static String f(double v, int decimals) { return String.format(Locale.ROOT, "%." + decimals + "f", v); }

    static MutableText labeled(String key, String value) { return Text.translatable(key).append(Text.literal(": " + value)); }

    static ButtonWidget toggle(int x, int y, int w, String key, BooleanSupplier get, Consumer<Boolean> set) {
        return ButtonWidget.builder(Text.translatable(key).append(": ").append(ScreenTexts.onOrOff(get.getAsBoolean())), b -> {
            set.accept(!get.getAsBoolean());
            WynConfig.save();
            b.setMessage(Text.translatable(key).append(": ").append(ScreenTexts.onOrOff(get.getAsBoolean())));
        }).dimensions(x, y, w, 20).build();
    }

    static ButtonWidget cycle(int x, int y, int w, String key, List<String> values, Supplier<String> get,
                              Consumer<String> set, Function<String, Text> valueLabel) {
        return ButtonWidget.builder(Text.translatable(key).append(": ").append(valueLabel.apply(get.get())), b -> {
            int i = values.indexOf(get.get());
            set.accept(values.get((i + 1) % values.size()));
            WynConfig.save();
            b.setMessage(Text.translatable(key).append(": ").append(valueLabel.apply(get.get())));
        }).dimensions(x, y, w, 20).build();
    }

    static ButtonWidget button(int x, int y, int w, Text label, Runnable action) {
        return ButtonWidget.builder(label, b -> action.run()).dimensions(x, y, w, 20).build();
    }
}
