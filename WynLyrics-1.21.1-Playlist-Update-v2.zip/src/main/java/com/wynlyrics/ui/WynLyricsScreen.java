package com.wynlyrics.ui;

import com.wynlyrics.config.WynConfig;
import com.wynlyrics.config.WynConfig.Config;
import com.wynlyrics.lyrics.FabricPaths;
import com.wynlyrics.lyrics.LrcPlayer;
import com.wynlyrics.render.Draw;
import com.wynlyrics.render.FontRegistry;
import com.wynlyrics.render.WorldLyricsRenderer;
import com.wynlyrics.spotify.SpotifyAuth;
import com.wynlyrics.spotify.SpotifyPlaylistService;
import com.wynlyrics.spotify.SpotifyPlaylistService.PlaylistTrack;
import com.wynlyrics.util.ColorUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.util.List;

/** Main settings screen with tabs. Opens the HUD editor and the cosmetic editor. */
public final class WynLyricsScreen extends Screen {
    private enum Tab { GENERAL, SPOTIFY, PLAYLIST, LYRICS, ANIMATION, WORLD }

    private static final int TRACK_ROWS = 5;
    private static final int TRACK_ROW_H = 17;

    private static Tab tab = Tab.GENERAL;
    private final Screen parent;
    private TextFieldWidget clientIdField;
    private TextFieldWidget playlistUrlField;
    private int playlistScroll = 0;
    private int savedIndex = 0;
    private SpotifyAuth.State shownState;
    private MusicPlayerWidget playerWidget;

    public WynLyricsScreen(Screen parent) {
        super(Text.translatable("wynlyrics.screen.title"));
        this.parent = parent;
    }

    private int colX(int col) { return width / 2 - 156 + col * 158; }
    private static final int COL_W = 154;

    @Override
    protected void init() {
        FontRegistry.refresh();
        Config c = WynConfig.CONFIG;
        int cx = width / 2;
        shownState = SpotifyAuth.state();

        // tabs
        Tab[] tabs = Tab.values();
        int tw = 51, total = tabs.length * tw + (tabs.length - 1) * 2, x0 = cx - total / 2;
        for (int i = 0; i < tabs.length; i++) {
            Tab tb = tabs[i];
            ButtonWidget b = Ui.button(x0 + i * (tw + 2), 20, tw, Text.translatable("wynlyrics.tab." + tb.name().toLowerCase()), () -> {
                tab = tb;
                clearAndInit();
            });
            b.setHeight(18);
            b.active = tab != tb;
            addDrawableChild(b);
        }

        int top = 48;
        switch (tab) {
            case GENERAL -> {
                addDrawableChild(Ui.toggle(colX(0), top, COL_W, "wynlyrics.opt.hud", () -> c.hudEnabled, v -> c.hudEnabled = v));
                addDrawableChild(Ui.toggle(colX(1), top, COL_W, "wynlyrics.opt.hud3d", () -> c.hud3dEnabled, v -> c.hud3dEnabled = v));
                addDrawableChild(Ui.toggle(colX(0), top + 24, COL_W, "wynlyrics.opt.show_track", () -> c.showTrack, v -> c.showTrack = v));
                addDrawableChild(Ui.toggle(colX(1), top + 24, COL_W, "wynlyrics.opt.show_artist", () -> c.showArtist, v -> c.showArtist = v));
                addDrawableChild(Ui.toggle(colX(0), top + 48, COL_W, "wynlyrics.opt.show_progress", () -> c.showProgress, v -> c.showProgress = v));
                addDrawableChild(Ui.toggle(colX(1), top + 48, COL_W, "wynlyrics.opt.hide_idle", () -> c.hideWhenIdle, v -> c.hideWhenIdle = v));
                addDrawableChild(Ui.toggle(colX(0), top + 72, COL_W, "wynlyrics.opt.player_bar", () -> c.showPlayerBar, v -> c.showPlayerBar = v));
                addDrawableChild(Ui.toggle(colX(1), top + 72, COL_W, "wynlyrics.opt.auto_lyrics", () -> c.autoFetchLyrics, v -> c.autoFetchLyrics = v));
                addDrawableChild(Ui.button(colX(0), top + 96, 312, Text.translatable("wynlyrics.opt.reset"), () -> {
                    WynConfig.resetKeepingSpotify();
                    clearAndInit();
                }));
            }
            case SPOTIFY -> initSpotify(c, top);
            case PLAYLIST -> initPlaylist(c, top);
            case LYRICS -> {
                addDrawableChild(new ConfigSlider(colX(0), top, COL_W, 20, 0, 2, 1, () -> c.linesBefore, v -> c.linesBefore = (int) v,
                        v -> Ui.labeled("wynlyrics.opt.lines_before", String.valueOf((int) v)), null));
                addDrawableChild(new ConfigSlider(colX(1), top, COL_W, 20, 0, 2, 1, () -> c.linesAfter, v -> c.linesAfter = (int) v,
                        v -> Ui.labeled("wynlyrics.opt.lines_after", String.valueOf((int) v)), null));
                addDrawableChild(new ConfigSlider(colX(0), top + 24, 312, 20, -2000, 2000, 50, () -> c.lyricsOffsetMs, v -> c.lyricsOffsetMs = (int) v,
                        v -> Ui.labeled("wynlyrics.opt.offset", ((int) v > 0 ? "+" : "") + (int) v + " ms"), null));
                addDrawableChild(Ui.toggle(colX(0), top + 48, 312, "wynlyrics.opt.per_track", () -> c.useSpotifyLyricsFile, v -> {
                    c.useSpotifyLyricsFile = v;
                    LrcPlayer.INSTANCE.reload();
                }));
                TextFieldWidget file = new TextFieldWidget(textRenderer, colX(0), top + 72, 208, 20, Text.translatable("wynlyrics.opt.lyrics_file"));
                file.setMaxLength(120);
                file.setText(c.lyricsFile);
                file.setChangedListener(s -> c.lyricsFile = s.isBlank() ? "current_song.lrc" : s.trim());
                addDrawableChild(file);
                addDrawableChild(Ui.button(colX(0) + 212, top + 72, 100, Text.translatable("wynlyrics.opt.reload"), () -> {
                    WynConfig.save();
                    LrcPlayer.INSTANCE.reload();
                }));
                addDrawableChild(Ui.button(colX(0), top + 96, 312, Text.translatable("wynlyrics.opt.open_folder"),
                        () -> Util.getOperatingSystem().open(FabricPaths.dir().toFile())));
            }
            case ANIMATION -> {
                addDrawableChild(Ui.cycle(colX(0), top, COL_W, "wynlyrics.opt.anim_type",
                        List.of("none", "fade", "slide", "zoom", "typewriter"), () -> c.animationType, v -> c.animationType = v,
                        v -> Text.translatable("wynlyrics.anim." + v)));
                addDrawableChild(new ConfigSlider(colX(1), top, COL_W, 20, 0, 1500, 50, () -> c.animationMs, v -> c.animationMs = (int) v,
                        v -> Ui.labeled("wynlyrics.opt.anim_ms", (int) v + " ms"), null));
                addDrawableChild(new ConfigSlider(colX(0), top + 24, COL_W, 20, 0, 1500, 50, () -> c.hudFadeMs, v -> c.hudFadeMs = (int) v,
                        v -> Ui.labeled("wynlyrics.opt.hud_fade", (int) v + " ms"), null));
                addDrawableChild(Ui.toggle(colX(1), top + 24, COL_W, "wynlyrics.opt.line_fill", () -> c.lineFill, v -> c.lineFill = v));
            }
            case WORLD -> {
                addDrawableChild(Ui.toggle(colX(0), top, COL_W, "wynlyrics.opt.hud3d", () -> c.hud3dEnabled, v -> c.hud3dEnabled = v));
                addDrawableChild(Ui.cycle(colX(1), top, COL_W, "wynlyrics.opt.w_mode", List.of("follow", "anchored"),
                        () -> c.world3dMode, v -> c.world3dMode = v, v -> Text.translatable("wynlyrics.mode." + v)));
                addDrawableChild(new ConfigSlider(colX(0), top + 24, COL_W, 20, 1, 12, 0.5, () -> c.world3dDistance, v -> c.world3dDistance = (float) v,
                        v -> Ui.labeled("wynlyrics.opt.w_distance", Ui.f(v, 1)), null));
                addDrawableChild(new ConfigSlider(colX(1), top + 24, COL_W, 20, -2, 3, 0.1, () -> c.world3dHeight, v -> c.world3dHeight = (float) v,
                        v -> Ui.labeled("wynlyrics.opt.w_height", Ui.f(v, 1)), null));
                addDrawableChild(new ConfigSlider(colX(0), top + 48, COL_W, 20, 0.3, 4, 0.1, () -> c.world3dScale, v -> c.world3dScale = (float) v,
                        v -> Ui.labeled("wynlyrics.opt.w_scale", Ui.f(v, 1) + "x"), null));
                addDrawableChild(Ui.toggle(colX(1), top + 48, COL_W, "wynlyrics.opt.w_bg", () -> c.world3dBackground, v -> c.world3dBackground = v));
                addDrawableChild(Ui.toggle(colX(0), top + 72, COL_W, "wynlyrics.opt.w_walls", () -> c.world3dThroughWalls, v -> c.world3dThroughWalls = v));
                addDrawableChild(Ui.toggle(colX(1), top + 72, COL_W, "wynlyrics.opt.w_track", () -> c.world3dShowTrack, v -> c.world3dShowTrack = v));
                addDrawableChild(Ui.button(colX(0), top + 96, 312, Text.translatable("wynlyrics.opt.w_pin"), () -> {
                    WorldLyricsRenderer.pinHere();
                    clearAndInit();
                }));
            }
        }

        // embedded music player widget
        int fy = height - 26;
        this.playerWidget = c.showPlayerBar ? new MusicPlayerWidget(cx - 156, fy - 46, 312, 43) : null;
        addDrawableChild(Ui.button(cx - 156, fy, 102, Text.translatable("wynlyrics.opt.hud_editor"),
                () -> { WynConfig.save(); client.setScreen(new HudEditorScreen(this)); }));
        addDrawableChild(Ui.button(cx - 51, fy, 102, Text.translatable("wynlyrics.opt.cosmetic"),
                () -> { WynConfig.save(); client.setScreen(new CosmeticEditorScreen(this)); }));
        addDrawableChild(Ui.button(cx + 54, fy, 102, Text.translatable("wynlyrics.opt.done"), this::close));
    }

    private void initSpotify(Config c, int top) {
        addDrawableChild(Ui.toggle(colX(0), top, 312, "wynlyrics.opt.spotify", () -> c.spotifyEnabled, v -> c.spotifyEnabled = v));

        clientIdField = new TextFieldWidget(textRenderer, colX(0), top + 24, 312, 20, Text.translatable("wynlyrics.opt.client_id"));
        clientIdField.setMaxLength(64);
        clientIdField.setText(c.spotifyClientId);
        clientIdField.setChangedListener(s -> {
            c.spotifyClientId = s.trim();
            WynConfig.save();
        });
        addDrawableChild(clientIdField);

        SpotifyAuth.State st = SpotifyAuth.state();
        boolean waiting = st == SpotifyAuth.State.WAITING || st == SpotifyAuth.State.EXCHANGING;
        ButtonWidget login = Ui.button(colX(0), top + 48, COL_W,
                Text.translatable(waiting ? "wynlyrics.opt.cancel" : "wynlyrics.opt.login"), () -> {
                    if (SpotifyAuth.state() == SpotifyAuth.State.WAITING || SpotifyAuth.state() == SpotifyAuth.State.EXCHANGING) SpotifyAuth.cancel();
                    else SpotifyAuth.startLogin();
                    clearAndInit();
                });
        login.active = waiting || !c.spotifyClientId.isBlank();
        addDrawableChild(login);

        ButtonWidget logout = Ui.button(colX(1), top + 48, COL_W, Text.translatable("wynlyrics.opt.logout"), () -> {
            SpotifyAuth.logout();
            clearAndInit();
        });
        logout.active = SpotifyAuth.isLoggedIn();
        addDrawableChild(logout);

        ButtonWidget copy = Ui.button(colX(0), top + 72, COL_W, Text.translatable("wynlyrics.opt.copy_link"), SpotifyAuth::copyLink);
        copy.active = st == SpotifyAuth.State.WAITING;
        addDrawableChild(copy);

        addDrawableChild(Ui.button(colX(1), top + 72, COL_W, Text.translatable("wynlyrics.opt.open_folder"),
                () -> Util.getOperatingSystem().open(FabricPaths.dir().toFile())));
    }

    private void initPlaylist(Config c, int top) {
        int leftX = colX(0);
        playlistUrlField = new TextFieldWidget(textRenderer, leftX, top, 250, 20, Text.translatable("wynlyrics.opt.playlist_url"));
        playlistUrlField.setMaxLength(256);
        playlistUrlField.setText(c.spotifyPlaylistUrl);
        playlistUrlField.setChangedListener(s -> c.spotifyPlaylistUrl = s.trim());
        addDrawableChild(playlistUrlField);

        ButtonWidget pasteBtn = Ui.button(leftX + 254, top, 58, Text.translatable("wynlyrics.opt.paste"), () -> {
            String clip = MinecraftClient.getInstance().keyboard.getClipboard();
            if (clip != null && !clip.isBlank()) {
                String clean = clip.trim();
                playlistUrlField.setText(clean);
                c.spotifyPlaylistUrl = clean;
                WynConfig.save();
            }
        });
        addDrawableChild(pasteBtn);

        int row2Y = top + 23;
        ButtonWidget playBtn = Ui.button(leftX, row2Y, 114, Text.translatable("wynlyrics.opt.playlist_play"), () -> {
            playlistScroll = 0;
            SpotifyPlaylistService.loadPlaylist(playlistUrlField.getText(), true);
        });
        playBtn.setHeight(18);
        addDrawableChild(playBtn);

        ButtonWidget loadBtn = Ui.button(leftX + 117, row2Y, 76, Text.translatable("wynlyrics.opt.playlist_load"), () -> {
            playlistScroll = 0;
            SpotifyPlaylistService.loadPlaylist(playlistUrlField.getText(), false);
        });
        loadBtn.setHeight(18);
        addDrawableChild(loadBtn);

        String savedLabel;
        if (c.savedPlaylists.isEmpty()) {
            savedLabel = Text.translatable("wynlyrics.opt.open_browser").getString();
        } else {
            int idx = Math.floorMod(savedIndex, c.savedPlaylists.size());
            savedLabel = "★ " + textRenderer.trimToWidth(c.savedPlaylists.get(idx).name, 94);
        }
        ButtonWidget savedBtn = Ui.button(leftX + 196, row2Y, 116, Text.literal(savedLabel), () -> {
            if (!c.savedPlaylists.isEmpty()) {
                savedIndex = (savedIndex + 1) % c.savedPlaylists.size();
                WynConfig.SavedPlaylist picked = c.savedPlaylists.get(savedIndex);
                playlistUrlField.setText(picked.url);
                c.spotifyPlaylistUrl = picked.url;
                WynConfig.save();
                playlistScroll = 0;
                SpotifyPlaylistService.loadPlaylist(picked.url, false);
                clearAndInit();
            } else {
                var parsed = SpotifyPlaylistService.parseLink(playlistUrlField.getText());
                if (parsed != null) {
                    Util.getOperatingSystem().open(parsed.webUrl());
                }
            }
        });
        savedBtn.setHeight(18);
        addDrawableChild(savedBtn);
    }

    @Override
    public void tick() {
        super.tick();
        if (tab == Tab.SPOTIFY && SpotifyAuth.state() != shownState) clearAndInit();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta); // draws the background itself
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 6, 0x55D6FF);

        if (playerWidget != null) {
            playerWidget.render(ctx, mouseX, mouseY);
        }
        if (tab == Tab.SPOTIFY) {
            int top = 48;
            SpotifyAuth.State st = SpotifyAuth.state();
            String msg = SpotifyAuth.message();
            Text status = Text.translatable("wynlyrics.spotify.state." + st.name().toLowerCase());
            if (!msg.isEmpty()) status = status.copy().append(Text.literal(" — " + msg));
            int color = switch (st) {
                case LOGGED_IN -> 0x55FF8A;
                case ERROR -> 0xFF6B6B;
                case WAITING, EXCHANGING -> 0xFFD166;
                default -> 0xAAAAAA;
            };
            ctx.drawCenteredTextWithShadow(textRenderer, status, width / 2, top + 100, color);
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.translatable("wynlyrics.spotify.redirect_hint", SpotifyAuth.redirectUri()), width / 2, top + 114, 0x888888);
            if (clientIdField != null && clientIdField.getText().isEmpty() && !clientIdField.isFocused()) {
                ctx.drawTextWithShadow(textRenderer, Text.translatable("wynlyrics.opt.client_id_hint"),
                        clientIdField.getX() + 4, clientIdField.getY() + 6, 0x666666);
            }
        } else if (tab == Tab.PLAYLIST) {
            renderPlaylistTab(ctx, mouseX, mouseY);
        }
    }

    private void renderPlaylistTab(DrawContext ctx, int mouseX, int mouseY) {
        int top = 48;
        int leftX = colX(0);
        int boxW = 312;

        if (playlistUrlField != null && playlistUrlField.getText().isEmpty() && !playlistUrlField.isFocused()) {
            ctx.drawTextWithShadow(textRenderer, Text.translatable("wynlyrics.opt.playlist_hint"),
                    playlistUrlField.getX() + 4, playlistUrlField.getY() + 6, 0x666666);
        }

        String msg = SpotifyPlaylistService.statusMessage();
        int statusColor;
        if (msg.isEmpty()) {
            msg = Text.translatable("wynlyrics.playlist.idle_hint").getString();
            statusColor = 0x9AA0AA;
        } else if (SpotifyPlaylistService.isLoading()) {
            statusColor = 0xFFD166;
        } else if (SpotifyPlaylistService.isStatusError()) {
            statusColor = 0xFF6B6B;
        } else {
            statusColor = 0x55FF8A;
        }
        String trimmedStatus = textRenderer.trimToWidth(msg, boxW);
        ctx.drawCenteredTextWithShadow(textRenderer, trimmedStatus, width / 2, top + 44, statusColor);

        int boxY = top + 56;
        int boxH = TRACK_ROWS * TRACK_ROW_H;
        Config c = WynConfig.CONFIG;
        Draw.fillRounded(ctx, leftX, boxY, leftX + boxW, boxY + boxH, 3, ColorUtil.argb(c.backgroundColor, 0.72f));
        ctx.drawBorder(leftX, boxY, boxW, boxH, ColorUtil.argb(c.accentColor, 0.45f));

        List<PlaylistTrack> tracks = SpotifyPlaylistService.tracks();
        if (tracks.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.translatable("wynlyrics.playlist.empty"),
                    width / 2, boxY + boxH / 2 - 4, 0x8892A4);
            return;
        }

        int maxScroll = Math.max(0, tracks.size() - TRACK_ROWS);
        if (playlistScroll > maxScroll) playlistScroll = maxScroll;
        if (playlistScroll < 0) playlistScroll = 0;

        int accent = 0xFF000000 | c.accentColor;
        for (int row = 0; row < TRACK_ROWS; row++) {
            int idx = playlistScroll + row;
            if (idx >= tracks.size()) break;
            PlaylistTrack tr = tracks.get(idx);
            int ry = boxY + row * TRACK_ROW_H;
            boolean hovered = mouseX >= leftX + 1 && mouseX <= leftX + boxW - 2 && mouseY >= ry && mouseY < ry + TRACK_ROW_H;
            if (hovered) {
                ctx.fill(leftX + 1, ry + 1, leftX + boxW - 1, ry + TRACK_ROW_H - 1, 0x33FFFFFF);
            }

            String durStr = Draw.time(tr.durationMs());
            int durW = textRenderer.getWidth(durStr);
            String prefix = (idx + 1) + ". ";
            String label = prefix + tr.title() + (tr.artist().isEmpty() ? "" : " - " + tr.artist());
            String trimmedLabel = textRenderer.trimToWidth(label, boxW - durW - 18);

            ctx.drawTextWithShadow(textRenderer, trimmedLabel, leftX + 5, ry + 4, hovered ? accent : 0xFFFFFFFF);
            ctx.drawText(textRenderer, durStr, leftX + boxW - durW - 7, ry + 4, 0xFF9AA0AA, false);
        }

        // Scrollbar indicator if more than TRACK_ROWS
        if (tracks.size() > TRACK_ROWS) {
            int sbH = Math.max(12, (int) ((TRACK_ROWS / (float) tracks.size()) * (boxH - 4)));
            int sbY = boxY + 2 + (int) ((playlistScroll / (float) maxScroll) * (boxH - 4 - sbH));
            ctx.fill(leftX + boxW - 3, sbY, leftX + boxW - 1, sbY + sbH, accent);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (playerWidget != null && playerWidget.mouseClicked(mouseX, mouseY, button)) return true;

        if (tab == Tab.PLAYLIST && button == 0) {
            int leftX = colX(0);
            int boxW = 312;
            int boxY = 48 + 56;
            int boxH = TRACK_ROWS * TRACK_ROW_H;
            List<PlaylistTrack> tracks = SpotifyPlaylistService.tracks();
            if (!tracks.isEmpty() && mouseX >= leftX && mouseX <= leftX + boxW && mouseY >= boxY && mouseY < boxY + boxH) {
                int row = (int) ((mouseY - boxY) / TRACK_ROW_H);
                int idx = playlistScroll + row;
                if (idx >= 0 && idx < tracks.size()) {
                    SpotifyPlaylistService.playTrackAt(idx);
                    MinecraftClient.getInstance().getSoundManager()
                            .play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        if (tab == Tab.PLAYLIST) {
            List<PlaylistTrack> tracks = SpotifyPlaylistService.tracks();
            if (tracks.size() > TRACK_ROWS) {
                int leftX = colX(0);
                int boxW = 312;
                int boxY = 48 + 56;
                int boxH = TRACK_ROWS * TRACK_ROW_H;
                if (mx >= leftX && mx <= leftX + boxW && my >= boxY && my <= boxY + boxH) {
                    int maxScroll = Math.max(0, tracks.size() - TRACK_ROWS);
                    playlistScroll = Math.max(0, Math.min(maxScroll, playlistScroll - (int) Math.signum(vAmount)));
                    return true;
                }
            }
        }
        return super.mouseScrolled(mx, my, hAmount, vAmount);
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void removed() { WynConfig.save(); }

    @Override
    public void close() { if (client != null) client.setScreen(parent); }
}
