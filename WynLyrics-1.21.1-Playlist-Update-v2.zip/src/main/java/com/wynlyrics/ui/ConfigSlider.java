package com.wynlyrics.ui;

import com.wynlyrics.config.WynConfig;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.DoubleSupplier;

/** Generic slider bound to a config value. */
public final class ConfigSlider extends SliderWidget {
    private final double min, max, step;
    private final DoubleSupplier getter;
    private final DoubleConsumer setter;
    private final DoubleFunction<Text> label;
    private final Runnable onChange;

    public ConfigSlider(int x, int y, int w, int h, double min, double max, double step,
                        DoubleSupplier getter, DoubleConsumer setter, DoubleFunction<Text> label, Runnable onChange) {
        super(x, y, w, h, Text.empty(), 0);
        this.min = min; this.max = max; this.step = step;
        this.getter = getter; this.setter = setter; this.label = label; this.onChange = onChange;
        sync();
    }

    /** Re-reads the config value (after reset or external change). */
    public void sync() {
        double v = Math.max(min, Math.min(max, getter.getAsDouble()));
        this.value = (v - min) / (max - min);
        updateMessage();
    }

    private double snap(double norm) {
        double v = min + norm * (max - min);
        if (step > 0) v = Math.round(v / step) * step;
        return Math.max(min, Math.min(max, v));
    }

    @Override protected void updateMessage() { setMessage(label.apply(snap(value))); }

    @Override protected void applyValue() {
        setter.accept(snap(value));
        if (onChange != null) onChange.run();
    }

    @Override public void onRelease(double mouseX, double mouseY) {
        super.onRelease(mouseX, mouseY);
        WynConfig.save();
    }
}
