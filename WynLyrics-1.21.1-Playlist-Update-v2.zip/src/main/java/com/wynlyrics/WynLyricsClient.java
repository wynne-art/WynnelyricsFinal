package com.wynlyrics;

import com.wynlyrics.config.WynConfig;
import com.wynlyrics.lyrics.LrcPlayer;
import com.wynlyrics.music.MusicPlaybackController;
import com.wynlyrics.render.HudRenderer;
import com.wynlyrics.render.WorldLyricsRenderer;
import com.wynlyrics.spotify.SpotifyAuth;
import com.wynlyrics.ui.WynLyricsScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class WynLyricsClient implements ClientModInitializer {
    public static final String MOD_ID = "wynlyrics";
    public static final Logger LOGGER = LoggerFactory.getLogger("WynLyrics");

    private static KeyBinding toggleKey;
    private static KeyBinding toggle3dKey;
    private static KeyBinding settingsKey;
    private static KeyBinding playPauseKey;
    private static KeyBinding nextTrackKey;
    private static KeyBinding prevTrackKey;
    private static KeyBinding muteKey;

    @Override
    public void onInitializeClient() {
        WynConfig.load();
        SpotifyAuth.load();
        MusicPlaybackController.getInstance().initFromConfig();
        LrcPlayer.INSTANCE.init();

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.wynlyrics.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_L, "key.category.wynlyrics"));
        toggle3dKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.wynlyrics.toggle3d", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, "key.category.wynlyrics"));
        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.wynlyrics.settings", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O, "key.category.wynlyrics"));
        playPauseKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.wynlyrics.play_pause", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_P, "key.category.wynlyrics"));
        nextTrackKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.wynlyrics.next", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_BRACKET, "key.category.wynlyrics"));
        prevTrackKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.wynlyrics.prev", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_BRACKET, "key.category.wynlyrics"));
        muteKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.wynlyrics.mute", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, "key.category.wynlyrics"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                WynConfig.CONFIG.hudEnabled = !WynConfig.CONFIG.hudEnabled;
                WynConfig.save();
            }
            while (toggle3dKey.wasPressed()) {
                WynConfig.CONFIG.hud3dEnabled = !WynConfig.CONFIG.hud3dEnabled;
                WynConfig.save();
            }
            while (settingsKey.wasPressed()) {
                client.setScreen(new WynLyricsScreen(client.currentScreen));
            }
            MusicPlaybackController player = MusicPlaybackController.getInstance();
            while (playPauseKey.wasPressed()) player.togglePlayPause();
            while (nextTrackKey.wasPressed()) player.nextTrack();
            while (prevTrackKey.wasPressed()) player.previousTrack();
            while (muteKey.wasPressed()) player.toggleMute();

            LrcPlayer.INSTANCE.tick();
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> HudRenderer.renderHud(drawContext));
        WorldRenderEvents.LAST.register(WorldLyricsRenderer::render);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> SpotifyAuth.shutdown());
    }
}
