package com.wynlyrics.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.wynlyrics.WynLyricsClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class WynConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("wynlyrics.json");

    public static Config CONFIG = new Config();

    private WynConfig() {}

    public static void load() {
        try {
            if (Files.exists(PATH)) {
                Config loaded = GSON.fromJson(Files.readString(PATH), Config.class);
                if (loaded != null) CONFIG = loaded;
            }
        } catch (Exception e) {
            WynLyricsClient.LOGGER.error("Failed to load config", e);
        }
        CONFIG.normalize();
        save();
    }

    public static void save() {
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(CONFIG));
        } catch (IOException e) {
            WynLyricsClient.LOGGER.error("Failed to save config", e);
        }
    }

    /** Resets everything except Spotify settings. */
    public static void resetKeepingSpotify() {
        Config old = CONFIG;
        Config fresh = new Config();
        fresh.spotifyEnabled = old.spotifyEnabled;
        fresh.spotifyClientId = old.spotifyClientId;
        fresh.spotifyRedirectPort = old.spotifyRedirectPort;
        fresh.spotifyAccessToken = old.spotifyAccessToken;
        fresh.spotifyPlaylistUrl = old.spotifyPlaylistUrl;
        fresh.savedPlaylists = new java.util.ArrayList<>(old.savedPlaylists);
        CONFIG = fresh;
        CONFIG.normalize();
        save();
    }


    public static final class SavedPlaylist {
        public String name = "";
        public String url = "";

        public SavedPlaylist() {}

        public SavedPlaylist(String name, String url) {
            this.name = name;
            this.url = url;
        }
    }

    public static final class Config {
        // ---- general
        public boolean hudEnabled = true;
        public boolean hud3dEnabled = false;
        public boolean showTrack = true;
        public boolean showArtist = true;
        public boolean showProgress = true;
        public boolean hideWhenIdle = true;

        // ---- spotify / lyrics source
        public boolean spotifyEnabled = false;
        public boolean useSpotifyLyricsFile = true;
        public boolean autoFetchLyrics = true;
        public boolean showPlayerBar = true;
        public int musicVolume = 80;
        public String musicSource = "SPOTIFY";
        public String spotifyClientId = "";
        public int spotifyRedirectPort = 8888;
        /** Legacy manual token. Only used when OAuth login is not active. */
        public String spotifyAccessToken = "";
        public String spotifyPlaylistUrl = "";
        public java.util.List<SavedPlaylist> savedPlaylists = new java.util.ArrayList<>();
        public String lyricsFile = "current_song.lrc";
        /** Positive = lyrics appear earlier. */
        public int lyricsOffsetMs = 0;
        public int linesBefore = 0;
        public int linesAfter = 1;

        // ---- HUD layout (set by the HUD editor)
        public float hudX = 0.5f;      // horizontal center, fraction of screen width
        public float hudY = 0.80f;     // top edge, fraction of screen height
        public float hudScale = 1.0f;
        public int hudWidth = 280;
        public String alignment = "center";

        // ---- cosmetics
        public String theme = "dark";
        public int textColor = 0xFFFFFF;
        public int accentColor = 0x55D6FF;
        public int inactiveColor = 0x9AA0AA;
        public int backgroundColor = 0x10131B;
        public int borderColor = 0x55D6FF;
        public int progressColor = 0x55D6FF;
        public int progressTrackColor = 0x444A55;
        public int outlineColor = 0x000000;
        public float backgroundOpacity = 0.55f;
        public float inactiveOpacity = 0.55f;
        public int cornerRadius = 3;
        public int borderThickness = 0;
        public boolean textShadow = true;
        public boolean textOutline = false;
        public boolean textGlow = false;
        public String fontId = "default";

        // ---- animation
        public String animationType = "slide"; // none | fade | slide | zoom | typewriter
        public int animationMs = 350;
        public int hudFadeMs = 250;
        public boolean lineFill = true;

        // ---- 3D floating lyrics
        public String world3dMode = "follow";  // follow | anchored
        public float world3dDistance = 3.5f;
        public float world3dHeight = 0.2f;
        public float world3dScale = 1.0f;
        public boolean world3dThroughWalls = false;
        public boolean world3dBackground = true;
        public boolean world3dShowTrack = true;
        public boolean anchorSet = false;
        public double anchorX, anchorY, anchorZ;
        public String anchorDimension = "";

        // ---- legacy fields from 0.x configs (migrated in normalize)
        public Integer fontScale = null;

        public void normalize() {
            if (fontScale != null) { hudScale = fontScale; fontScale = null; }
            if (lyricsFile == null || lyricsFile.isBlank()) lyricsFile = "current_song.lrc";
            if (musicSource == null || musicSource.isBlank()) musicSource = "SPOTIFY";
            musicVolume = clamp(musicVolume, 0, 100);
            if (spotifyClientId == null) spotifyClientId = "";
            if (spotifyAccessToken == null) spotifyAccessToken = "";
            if (spotifyPlaylistUrl == null) spotifyPlaylistUrl = "";
            if (savedPlaylists == null) savedPlaylists = new java.util.ArrayList<>();
            savedPlaylists.removeIf(p -> p == null || p.url == null || p.url.isBlank());
            if (!"left".equalsIgnoreCase(alignment) && !"right".equalsIgnoreCase(alignment)) alignment = "center";
            alignment = alignment.toLowerCase();
            if (theme == null) theme = "custom";
            if (fontId == null) fontId = "default";
            if (animationType == null) animationType = "slide";
            if (!"anchored".equals(world3dMode)) world3dMode = "follow";
            if (anchorDimension == null) anchorDimension = "";
            spotifyRedirectPort = clamp(spotifyRedirectPort, 1024, 65535);
            lyricsOffsetMs = clamp(lyricsOffsetMs, -5000, 5000);
            linesBefore = clamp(linesBefore, 0, 2);
            linesAfter = clamp(linesAfter, 0, 2);
            hudX = clamp(hudX, 0f, 1f);
            hudY = clamp(hudY, 0f, 1f);
            hudScale = clamp(hudScale, 0.5f, 3f);
            hudWidth = clamp(hudWidth, 140, 520);
            backgroundOpacity = clamp(backgroundOpacity, 0f, 1f);
            inactiveOpacity = clamp(inactiveOpacity, 0.1f, 1f);
            cornerRadius = clamp(cornerRadius, 0, 8);
            borderThickness = clamp(borderThickness, 0, 3);
            animationMs = clamp(animationMs, 0, 1500);
            hudFadeMs = clamp(hudFadeMs, 0, 1500);
            world3dDistance = clamp(world3dDistance, 1f, 12f);
            world3dHeight = clamp(world3dHeight, -2f, 3f);
            world3dScale = clamp(world3dScale, 0.3f, 4f);
        }

        private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
        private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }

        public void applyTheme(ThemePreset t) {
            theme = t.id();
            textColor = t.text(); accentColor = t.accent(); inactiveColor = t.inactive();
            backgroundColor = t.bg(); borderColor = t.border();
            progressColor = t.progress(); progressTrackColor = t.track();
            backgroundOpacity = t.bgOpacity();
        }
    }
}
