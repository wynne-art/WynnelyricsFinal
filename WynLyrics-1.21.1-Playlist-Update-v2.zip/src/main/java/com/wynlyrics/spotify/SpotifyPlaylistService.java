package com.wynlyrics.spotify;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.wynlyrics.WynLyricsClient;
import com.wynlyrics.config.WynConfig;
import com.wynlyrics.music.MusicPlaybackController;
import net.minecraft.client.resource.language.I18n;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses Spotify playlist/album/track links, fetches tracklists via Spotify Web API,
 * and starts playback on the user's active Spotify device (auto-selecting an available device if needed).
 */
public final class SpotifyPlaylistService {
    public record ParsedTarget(String type, String id, String contextUri, String webUrl) {}
    public record PlaylistTrack(String title, String artist, String uri, long durationMs) {}

    private static final Gson GSON = new Gson();
    private static final Pattern URI_PATTERN =
            Pattern.compile("^spotify:(playlist|album|track):([A-Za-z0-9]{10,40})$", Pattern.CASE_INSENSITIVE);
    private static final Pattern URL_PATTERN =
            Pattern.compile("^(?:https?://)?open\\.spotify\\.com/(?:intl-[a-zA-Z-]+/)?(playlist|album|track)/([A-Za-z0-9]{10,40})(?:[/?#].*)?$", Pattern.CASE_INSENSITIVE);
    private static final Pattern RAW_ID_PATTERN =
            Pattern.compile("^[A-Za-z0-9]{22}$");

    private static volatile boolean loading = false;
    private static volatile String statusMessage = "";
    private static volatile boolean statusError = false;
    private static volatile String loadedName = "";
    private static volatile String loadedOwner = "";
    private static volatile ParsedTarget currentTarget = null;
    private static volatile List<PlaylistTrack> tracks = List.of();

    private SpotifyPlaylistService() {}

    public static boolean isLoading() { return loading; }
    public static String statusMessage() { return statusMessage; }
    public static boolean isStatusError() { return statusError; }
    public static String loadedName() { return loadedName; }
    public static String loadedOwner() { return loadedOwner; }
    public static ParsedTarget currentTarget() { return currentTarget; }
    public static List<PlaylistTrack> tracks() { return tracks; }

    /** Parses a Spotify share link, URI, or 22-character playlist ID. */
    public static ParsedTarget parseLink(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (s.isEmpty()) return null;

        Matcher mUri = URI_PATTERN.matcher(s);
        if (mUri.matches()) {
            return buildTarget(mUri.group(1).toLowerCase(), mUri.group(2));
        }

        Matcher mUrl = URL_PATTERN.matcher(s);
        if (mUrl.matches()) {
            return buildTarget(mUrl.group(1).toLowerCase(), mUrl.group(2));
        }

        if (RAW_ID_PATTERN.matcher(s).matches()) {
            return buildTarget("playlist", s);
        }
        return null;
    }

    private static ParsedTarget buildTarget(String type, String id) {
        String contextUri = "track".equals(type) ? null : "spotify:" + type + ":" + id;
        String webUrl = "https://open.spotify.com/" + type + "/" + id;
        return new ParsedTarget(type, id, contextUri, webUrl);
    }

    /** Loads playlist metadata/tracks from Spotify and optionally begins playback immediately. */
    public static void loadPlaylist(String rawUrl, boolean autoPlay) {
        ParsedTarget target = parseLink(rawUrl);
        if (target == null) {
            statusMessage = I18n.translate("wynlyrics.playlist.invalid_link");
            statusError = true;
            return;
        }

        String trimmed = rawUrl.trim();
        WynConfig.CONFIG.spotifyPlaylistUrl = trimmed;
        WynConfig.save();

        if (loading) return;
        loading = true;
        statusError = false;
        statusMessage = I18n.translate("wynlyrics.playlist.loading");

        Thread t = new Thread(() -> {
            try {
                String token = resolveToken();
                if (token == null) {
                    statusMessage = I18n.translate("wynlyrics.playlist.not_logged_in");
                    statusError = true;
                    return;
                }

                boolean fetched = fetchTarget(token, target, trimmed);
                if (fetched && autoPlay) {
                    playInternal(token, target, null);
                }
            } catch (Exception e) {
                WynLyricsClient.LOGGER.warn("Playlist load failed: {}", e.getMessage());
                statusMessage = "Error: " + e.getMessage();
                statusError = true;
            } finally {
                loading = false;
            }
        }, "WynLyrics-Playlist");
        t.setDaemon(true);
        t.start();
    }

    /** Starts playback of a specific song inside the currently loaded playlist/album. */
    public static void playTrackAt(int index) {
        List<PlaylistTrack> list = tracks;
        ParsedTarget target = currentTarget;
        if (target == null || index < 0 || index >= list.size() || loading) return;

        PlaylistTrack chosen = list.get(index);
        loading = true;
        statusError = false;
        statusMessage = I18n.translate("wynlyrics.playlist.starting", chosen.title());

        Thread t = new Thread(() -> {
            try {
                String token = resolveToken();
                if (token == null) {
                    statusMessage = I18n.translate("wynlyrics.playlist.not_logged_in");
                    statusError = true;
                    return;
                }
                playInternal(token, target, chosen.uri());
            } catch (Exception e) {
                WynLyricsClient.LOGGER.warn("Playlist track play failed: {}", e.getMessage());
                statusMessage = "Error: " + e.getMessage();
                statusError = true;
            } finally {
                loading = false;
            }
        }, "WynLyrics-PlaylistPlay");
        t.setDaemon(true);
        t.start();
    }

    private static String resolveToken() {
        String token = SpotifyAuth.validToken();
        if (token == null) {
            String legacy = WynConfig.CONFIG.spotifyAccessToken;
            if (legacy != null && !legacy.isBlank()) token = legacy.trim();
        }
        return (token == null || token.isBlank()) ? null : token;
    }

    private static boolean fetchTarget(String token, ParsedTarget target, String rawUrl) throws Exception {
        Map<String, String> headers = Map.of("Authorization", "Bearer " + token);
        String apiUrl = switch (target.type()) {
            case "album" -> "https://api.spotify.com/v1/albums/" + target.id();
            case "track" -> "https://api.spotify.com/v1/tracks/" + target.id();
            default -> "https://api.spotify.com/v1/playlists/" + target.id()
                    + "?fields=name,owner(display_name),tracks.items(track(name,uri,duration_ms,artists(name)))";
        };

        Http.Response res = Http.get(apiUrl, headers, 9000);
        if (res.code() == 401) {
            SpotifyAuth.invalidateAccess();
            String refreshed = resolveToken();
            if (refreshed != null) {
                res = Http.get(apiUrl, Map.of("Authorization", "Bearer " + refreshed), 9000);
            }
        }

        if (res.code() == 404) {
            statusMessage = I18n.translate("wynlyrics.playlist.not_found");
            statusError = true;
            return false;
        }
        if (res.code() == 403) {
            statusMessage = I18n.translate("wynlyrics.playlist.forbidden");
            statusError = true;
            return false;
        }
        if (res.code() != 200 || res.body() == null || res.body().isBlank()) {
            statusMessage = "Spotify HTTP " + res.code();
            statusError = true;
            return false;
        }

        JsonObject root = JsonParser.parseString(res.body()).getAsJsonObject();
        List<PlaylistTrack> parsed = new ArrayList<>();
        String name = root.has("name") && !root.get("name").isJsonNull() ? root.get("name").getAsString() : "Spotify Playlist";
        String owner = "";

        if ("track".equals(target.type())) {
            PlaylistTrack single = parseTrackObj(root);
            if (single != null) {
                parsed.add(single);
                owner = single.artist();
            }
        } else if ("album".equals(target.type())) {
            owner = extractArtists(root);
            if (root.has("tracks") && root.get("tracks").isJsonObject()) {
                JsonArray items = root.getAsJsonObject("tracks").getAsJsonArray("items");
                if (items != null) {
                    for (JsonElement el : items) {
                        if (!el.isJsonObject()) continue;
                        PlaylistTrack tr = parseTrackObj(el.getAsJsonObject());
                        if (tr != null) parsed.add(tr);
                    }
                }
            }
        } else {
            if (root.has("owner") && root.get("owner").isJsonObject()) {
                JsonObject ow = root.getAsJsonObject("owner");
                if (ow.has("display_name") && !ow.get("display_name").isJsonNull()) {
                    owner = ow.get("display_name").getAsString();
                }
            }
            if (root.has("tracks") && root.get("tracks").isJsonObject()) {
                JsonArray items = root.getAsJsonObject("tracks").getAsJsonArray("items");
                if (items != null) {
                    for (JsonElement el : items) {
                        if (!el.isJsonObject()) continue;
                        JsonObject itemObj = el.getAsJsonObject();
                        if (!itemObj.has("track") || !itemObj.get("track").isJsonObject()) continue;
                        PlaylistTrack tr = parseTrackObj(itemObj.getAsJsonObject("track"));
                        if (tr != null) parsed.add(tr);
                        if (parsed.size() >= 60) break;
                    }
                }
            }
        }

        loadedName = name;
        loadedOwner = owner;
        currentTarget = target;
        tracks = List.copyOf(parsed);
        rememberPlaylist(name, rawUrl);

        statusError = false;
        statusMessage = I18n.translate("wynlyrics.playlist.loaded", name, parsed.size());
        return true;
    }

    private static PlaylistTrack parseTrackObj(JsonObject obj) {
        if (obj == null || !obj.has("name") || obj.get("name").isJsonNull()) return null;
        String title = obj.get("name").getAsString();
        String uri = obj.has("uri") && !obj.get("uri").isJsonNull() ? obj.get("uri").getAsString() : "";
        long dur = obj.has("duration_ms") && !obj.get("duration_ms").isJsonNull() ? obj.get("duration_ms").getAsLong() : 0L;
        String artist = extractArtists(obj);
        return new PlaylistTrack(title, artist, uri, dur);
    }

    private static String extractArtists(JsonObject obj) {
        if (!obj.has("artists") || !obj.get("artists").isJsonArray()) return "";
        StringBuilder sb = new StringBuilder();
        for (JsonElement a : obj.getAsJsonArray("artists")) {
            if (!a.isJsonObject()) continue;
            JsonObject ao = a.getAsJsonObject();
            if (ao.has("name") && !ao.get("name").isJsonNull()) {
                if (!sb.isEmpty()) sb.append(", ");
                sb.append(ao.get("name").getAsString());
            }
        }
        return sb.toString();
    }

    private static void playInternal(String token, ParsedTarget target, String trackUri) throws Exception {
        String payload;
        if ("track".equals(target.type())) {
            String u = (trackUri != null && !trackUri.isBlank()) ? trackUri : "spotify:track:" + target.id();
            payload = "{\"uris\":[" + GSON.toJson(u) + "]}";
        } else if (trackUri != null && !trackUri.isBlank()) {
            payload = "{\"context_uri\":" + GSON.toJson(target.contextUri())
                    + ",\"offset\":{\"uri\":" + GSON.toJson(trackUri) + "}}";
        } else {
            payload = "{\"context_uri\":" + GSON.toJson(target.contextUri()) + "}";
        }

        Map<String, String> headers = Map.of("Authorization", "Bearer " + token);
        String playUrl = "https://api.spotify.com/v1/me/player/play";
        Http.Response res = Http.sendJson("PUT", playUrl, headers, payload, 8000);

        // If no active device is awake (HTTP 404), auto-select first available Spotify device and retry
        if (res.code() == 404) {
            String deviceId = findAvailableDeviceId(token);
            if (deviceId != null) {
                String encDevice = URLEncoder.encode(deviceId, StandardCharsets.UTF_8);
                res = Http.sendJson("PUT", playUrl + "?device_id=" + encDevice, headers, payload, 8000);
            }
        }

        if (res.code() == 200 || res.code() == 204) {
            WynConfig.CONFIG.spotifyEnabled = true;
            WynConfig.save();
            MusicPlaybackController.getInstance().setActiveSource(MusicPlaybackController.MusicSource.SPOTIFY);
            SpotifyClient.requestImmediatePoll();
            statusError = false;
            statusMessage = I18n.translate("wynlyrics.playlist.playing", loadedName.isEmpty() ? target.type() : loadedName);
        } else if (res.code() == 403) {
            statusError = true;
            statusMessage = I18n.translate("wynlyrics.playlist.premium_required");
        } else if (res.code() == 404) {
            statusError = true;
            statusMessage = I18n.translate("wynlyrics.playlist.no_device");
        } else {
            statusError = true;
            statusMessage = "Play error (HTTP " + res.code() + ")";
        }
    }

    private static String findAvailableDeviceId(String token) {
        try {
            Http.Response res = Http.get("https://api.spotify.com/v1/me/player/devices",
                    Map.of("Authorization", "Bearer " + token), 6000);
            if (res.code() != 200 || res.body() == null || res.body().isBlank()) return null;
            JsonObject root = JsonParser.parseString(res.body()).getAsJsonObject();
            if (!root.has("devices") || !root.get("devices").isJsonArray()) return null;
            JsonArray arr = root.getAsJsonArray("devices");
            String fallbackId = null;
            for (JsonElement el : arr) {
                if (!el.isJsonObject()) continue;
                JsonObject dev = el.getAsJsonObject();
                String id = dev.has("id") && !dev.get("id").isJsonNull() ? dev.get("id").getAsString() : null;
                if (id == null || id.isBlank()) continue;
                if (dev.has("is_active") && dev.get("is_active").getAsBoolean()) return id;
                if (fallbackId == null) fallbackId = id;
            }
            return fallbackId;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static synchronized void rememberPlaylist(String name, String url) {
        List<WynConfig.SavedPlaylist> list = WynConfig.CONFIG.savedPlaylists;
        list.removeIf(p -> p == null || p.url == null || p.url.equalsIgnoreCase(url));
        list.add(0, new WynConfig.SavedPlaylist(name, url));
        while (list.size() > 8) {
            list.remove(list.size() - 1);
        }
        WynConfig.save();
    }
}
