package com.wynlyrics.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Custom fonts are regular Minecraft font definitions (assets/wynlyrics/font/*.json)
 * backed by TTF files. Entries whose TTF is missing are hidden and fall back to the default font.
 */
public final class FontRegistry {
    public record Entry(String id, String label, Identifier font, String ttf) {}

    private static final List<Entry> ALL = List.of(
            new Entry("default", "Minecraft", Identifier.of("minecraft", "default"), null),
            new Entry("poppins", "Poppins", Identifier.of("wynlyrics", "poppins"), "poppins.ttf"),
            new Entry("poppins_bold", "Poppins Bold", Identifier.of("wynlyrics", "poppins_bold"), "poppins_bold.ttf"),
            new Entry("bebas", "Bebas Neue", Identifier.of("wynlyrics", "bebas"), "bebas.ttf"),
            new Entry("lobster", "Lobster", Identifier.of("wynlyrics", "lobster"), "lobster.ttf"),
            new Entry("pacifico", "Pacifico", Identifier.of("wynlyrics", "pacifico"), "pacifico.ttf"),
            new Entry("righteous", "Righteous", Identifier.of("wynlyrics", "righteous"), "righteous.ttf"),
            new Entry("satisfy", "Satisfy", Identifier.of("wynlyrics", "satisfy"), "satisfy.ttf"),
            new Entry("uniform", "Unicode", Identifier.of("minecraft", "uniform"), null)
    );

    private static Set<String> available = null;

    private FontRegistry() {}

    /** Re-scans resource packs (call when opening a settings screen or after a resource reload). */
    public static synchronized void refresh() {
        Set<String> found = new HashSet<>();
        MinecraftClient mc = MinecraftClient.getInstance();
        for (Entry e : ALL) {
            if (e.ttf() == null) { found.add(e.id()); continue; }
            try {
                if (mc.getResourceManager().getResource(Identifier.of("wynlyrics", "font/" + e.ttf())).isPresent()) found.add(e.id());
            } catch (Exception ignored) {}
        }
        available = found;
    }

    public static synchronized List<Entry> available() {
        if (available == null) refresh();
        List<Entry> out = new ArrayList<>();
        for (Entry e : ALL) if (available.contains(e.id())) out.add(e);
        return out;
    }

    public static Style style(String id) {
        if (id == null || id.equals("default")) return Style.EMPTY;
        for (Entry e : available()) if (e.id().equals(id)) return Style.EMPTY.withFont(e.font());
        return Style.EMPTY;
    }

    public static MutableText text(String s) { return Text.literal(s).setStyle(style(com.wynlyrics.config.WynConfig.CONFIG.fontId)); }

    public static MutableText text(String s, String fontId) { return Text.literal(s).setStyle(style(fontId)); }
}
