package com.wynlyrics.render;

import com.wynlyrics.config.WynConfig;
import com.wynlyrics.config.WynConfig.Config;
import com.wynlyrics.lyrics.LrcPlayer;
import com.wynlyrics.lyrics.LyricSource;
import com.wynlyrics.lyrics.LyricView;
import com.wynlyrics.util.ColorUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

import java.util.List;

public final class HudRenderer {
    public static final LyricView LIVE = new LyricView(LrcPlayer.INSTANCE);
    /** Set by the editor screens so the real HUD does not draw underneath their preview. */
    public static volatile boolean editing = false;
    /** Screen-space bounds of the last drawn box: {x, y, w, h}. */
    public static final int[] lastBounds = new int[4];

    private static final int PAD = 8;
    private static final int LINE_H = 13;
    private static final int HEADER_H = 13;
    private static final int PROGRESS_H = 12;

    private static float vis = 0f;
    private static long lastNs = System.nanoTime();

    private HudRenderer() {}

    public static LyricView.Params params() {
        Config c = WynConfig.CONFIG;
        return new LyricView.Params(c.linesBefore, c.linesAfter, c.animationType, c.animationMs,
                c.inactiveOpacity, c.lineFill, c.textColor, c.inactiveColor);
    }

    /** Unscaled height of the lyric box for the current settings. */
    public static int boxHeight(LyricSource src) {
        Config c = WynConfig.CONFIG;
        int h = PAD + (c.showTrack ? HEADER_H : 0) + (c.linesBefore + 1 + c.linesAfter) * LINE_H + 4;
        if (c.showProgress && src.durationMs() > 0) h += PROGRESS_H;
        return h + 2;
    }

    // ------------------------------------------------------------ in-game HUD

    public static void renderHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Config c = WynConfig.CONFIG;
        long ns = System.nanoTime();
        float dtMs = Math.min(100f, (ns - lastNs) / 1_000_000f);
        lastNs = ns;

        boolean wants = c.hudEnabled && !editing && !mc.options.hudHidden
                && !(c.hideWhenIdle && LrcPlayer.INSTANCE.isIdle());
        float step = c.hudFadeMs <= 0 ? 1f : dtMs / c.hudFadeMs;
        vis = wants ? Math.min(1f, vis + step) : Math.max(0f, vis - step);
        if (vis <= 0.01f) return;

        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        draw(ctx, mc.textRenderer, LIVE, Math.round(c.hudX * w), Math.round(c.hudY * h), c.hudScale, c.hudWidth, vis);
    }

    // ------------------------------------------------------------ box drawing (shared with editors)

    /**
     * Draws the lyric box. (centerX, top) are screen pixels of the box's top-centre.
     * Returns and stores the final bounds {x, y, w, h}.
     */
    public static int[] draw(DrawContext ctx, TextRenderer tr, LyricView view, int centerX, int top,
                             float scale, int boxW, float vis) {
        Config c = WynConfig.CONFIG;
        MinecraftClient mc = MinecraftClient.getInstance();
        LyricSource src = view.source();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        int boxH = boxHeight(src);
        float pw = boxW * scale, ph = boxH * scale;
        float left = centerX - pw / 2f;
        left = Math.max(2f, Math.min(left, sw - pw - 2f));
        float topF = Math.max(0f, Math.min(top, sh - ph));

        lastBounds[0] = Math.round(left); lastBounds[1] = Math.round(topF);
        lastBounds[2] = Math.round(pw);   lastBounds[3] = Math.round(ph);

        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(left, topF, 0f);
        m.scale(scale, scale, 1f);

        // background + border
        int r = c.cornerRadius, t = c.borderThickness;
        float bgA = c.backgroundOpacity * vis;
        if (t > 0) {
            Draw.fillRounded(ctx, 0, 0, boxW, boxH, r, ColorUtil.argb(c.borderColor, vis));
            Draw.fillRounded(ctx, t, t, boxW - t, boxH - t, Math.max(0, r - t), ColorUtil.argb(c.backgroundColor, Math.max(bgA, 0.35f * vis)));
        } else if (bgA > 0.004f) {
            Draw.fillRounded(ctx, 0, 0, boxW, boxH, r, ColorUtil.argb(c.backgroundColor, bgA));
        }

        int y = 6;
        int pad = PAD + t;
        // header
        if (c.showTrack) {
            String head = src.title();
            if (c.showArtist && !src.artist().isBlank()) head += (head.isBlank() ? "" : "  \u2022  ") + src.artist();
            if (!head.isBlank()) {
                drawLine(ctx, tr, head, anchorX(boxW, pad), y + 1, 0.85f, c.accentColor, vis, -1f, boxW - pad * 2, false);
            }
            y += HEADER_H;
        }

        // lyrics
        List<LyricView.Item> items = view.compute(params(), System.currentTimeMillis());
        if (items.isEmpty()) {
            String key = src.statusKey();
            String status = "\u266A  " + I18n.translate(key.isEmpty() ? "wynlyrics.status.no_lyrics" : key);
            float ty = y + c.linesBefore * LINE_H;
            drawLine(ctx, tr, status, anchorX(boxW, pad), ty + (LINE_H - 9) / 2f, 1f, c.inactiveColor, vis, -1f, boxW - pad * 2, true);
        } else {
            for (LyricView.Item it : items) {
                float alpha = it.alpha() * vis;
                if (alpha < 0.03f) continue;
                float cy = y + (c.linesBefore + it.slot()) * LINE_H + LINE_H / 2f;
                drawLine(ctx, tr, it.text(), anchorX(boxW, pad), cy - 4.5f * it.scale(), it.scale(),
                        it.rgb(), alpha, it.fill(), boxW - pad * 2, true);
            }
        }
        y += (c.linesBefore + 1 + c.linesAfter) * LINE_H + 4;

        // progress
        if (c.showProgress && src.durationMs() > 0) {
            long pos = src.positionMs(), dur = src.durationMs();
            String left0 = Draw.time(pos), right0 = Draw.time(dur);
            int lw = tr.getWidth(right0) + 2;
            int bx = pad + lw, bw = boxW - pad * 2 - lw * 2;
            int by = y + 4;
            ctx.fill(bx, by, bx + bw, by + 2, ColorUtil.argb(c.progressTrackColor, vis));
            int fillW = (int) (bw * Math.min(1.0, pos / (double) dur));
            ctx.fill(bx, by, bx + fillW, by + 2, ColorUtil.argb(c.progressColor, vis));
            int tc = ColorUtil.argb(c.inactiveColor, vis);
            if (vis * 255 > 8) {
                ctx.drawText(tr, left0, pad, y, tc, false);
                ctx.drawText(tr, right0, boxW - pad - tr.getWidth(right0), y, tc, false);
            }
        }

        m.pop();
        return lastBounds;
    }

    private static float anchorX(int boxW, int pad) {
        return switch (WynConfig.CONFIG.alignment) {
            case "left" -> pad;
            case "right" -> boxW - pad;
            default -> boxW / 2f;
        };
    }

    /** Draws one line at local (matrix) coordinates, honouring alignment, font, effects and karaoke fill. */
    private static void drawLine(DrawContext ctx, TextRenderer tr, String text, float ax, float ty, float sc,
                                 int rgb, float alpha, float fill, int maxW, boolean allowEffects) {
        Config c = WynConfig.CONFIG;
        if (alpha * 255f < 8f || text.isEmpty()) return;
        Style st = FontRegistry.style(c.fontId);
        Text full = Text.literal(text).setStyle(st);
        float w = tr.getWidth(full);
        float s = sc;
        if (w * s > maxW) s = Math.max(sc * 0.7f, maxW / w);
        if (w * s > maxW) {
            int allow = (int) (maxW / s) - tr.getWidth("\u2026");
            String cut = tr.trimToWidth(full, Math.max(8, allow)).getString();
            text = cut + "\u2026";
            full = Text.literal(text).setStyle(st);
            w = tr.getWidth(full);
        }
        float x0 = switch (c.alignment) {
            case "left" -> ax;
            case "right" -> ax - w * s;
            default -> ax - w * s / 2f;
        };

        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(x0, ty, 0f);
        m.scale(s, s, 1f);

        boolean karaoke = fill >= 0f && c.lineFill && allowEffects;
        int base = ColorUtil.argb(rgb, alpha);

        if (allowEffects && c.textGlow) {
            int g = ColorUtil.argb(c.accentColor, alpha * 0.16f);
            for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) {
                if (dx != 0 || dy != 0) ctx.drawText(tr, full, dx, dy, g, false);
            }
        }
        if (allowEffects && c.textOutline) {
            int o = ColorUtil.argb(c.outlineColor, alpha);
            ctx.drawText(tr, full, 1, 0, o, false);
            ctx.drawText(tr, full, -1, 0, o, false);
            ctx.drawText(tr, full, 0, 1, o, false);
            ctx.drawText(tr, full, 0, -1, o, false);
        }
        ctx.drawText(tr, full, 0, 0, base, c.textShadow);
        if (karaoke) {
            int cps = text.codePointCount(0, text.length());
            int n = Math.round(fill * cps);
            if (n > 0) {
                String pre = text.substring(0, text.offsetByCodePoints(0, Math.min(n, cps)));
                ctx.drawText(tr, Text.literal(pre).setStyle(st), 0, 0, ColorUtil.argb(c.accentColor, alpha), false);
            }
        }
        m.pop();
    }
}
