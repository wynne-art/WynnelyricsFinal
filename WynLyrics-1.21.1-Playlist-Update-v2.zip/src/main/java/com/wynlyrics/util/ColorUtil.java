package com.wynlyrics.util;

import java.util.Locale;

public final class ColorUtil {
    private ColorUtil() {}

    /** RGB (0xRRGGBB) + alpha 0..1 -> ARGB int. */
    public static int argb(int rgb, float alpha) {
        int a = Math.round(Easing.clamp01(alpha) * 255f);
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    public static int lerpRgb(int a, int b, float t) {
        t = Easing.clamp01(t);
        int r = Math.round(Easing.lerp((a >> 16) & 255, (b >> 16) & 255, t));
        int g = Math.round(Easing.lerp((a >> 8) & 255, (b >> 8) & 255, t));
        int bl = Math.round(Easing.lerp(a & 255, b & 255, t));
        return (r << 16) | (g << 8) | bl;
    }

    public static String hex(int rgb) { return String.format(Locale.ROOT, "#%06X", rgb & 0xFFFFFF); }

    /** Accepts "#RRGGBB", "RRGGBB" or "#RGB". Returns -1 when invalid. */
    public static int parseHex(String s) {
        if (s == null) return -1;
        s = s.trim();
        if (s.startsWith("#")) s = s.substring(1);
        try {
            if (s.length() == 3) {
                int r = Integer.parseInt(s.substring(0, 1), 16);
                int g = Integer.parseInt(s.substring(1, 2), 16);
                int b = Integer.parseInt(s.substring(2, 3), 16);
                return ((r * 17) << 16) | ((g * 17) << 8) | (b * 17);
            }
            if (s.length() == 6) return Integer.parseInt(s, 16);
        } catch (NumberFormatException ignored) {}
        return -1;
    }
}
